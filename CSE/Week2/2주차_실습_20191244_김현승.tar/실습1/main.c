#include "header.h"


int main()
{
	He();
	llo();
	blank();
	World();
	return 0;
}
