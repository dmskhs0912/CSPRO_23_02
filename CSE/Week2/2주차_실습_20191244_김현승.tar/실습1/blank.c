#include "header.h"

void blank()
{
	printf(" ");
}

