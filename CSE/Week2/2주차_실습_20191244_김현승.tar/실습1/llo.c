#include "header.h"

void llo()
{
	printf("llo");
}

