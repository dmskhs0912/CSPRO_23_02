#include "header.h"

void He()
{
	printf("He");
}

