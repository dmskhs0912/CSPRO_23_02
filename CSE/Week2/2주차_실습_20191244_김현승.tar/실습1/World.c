#include "header.h"

void World()
{
	printf("World\n");
}

